use strict;
use warnings;

my $num = 1;

$num += 2;

print $num;
