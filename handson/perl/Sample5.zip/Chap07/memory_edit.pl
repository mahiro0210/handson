use strict;
use warnings;
while (my $line = <>) {
    print "memory_edit: $line";
}
