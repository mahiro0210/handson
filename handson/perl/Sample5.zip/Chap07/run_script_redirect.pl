my $command = 'perl hello.pl > output.txt';
system($command);