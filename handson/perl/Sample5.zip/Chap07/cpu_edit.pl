use strict;
use warnings;

while (my $line = <>) {
    print "cpu_edit: $line";
}
