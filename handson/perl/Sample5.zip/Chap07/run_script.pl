my $command = 'perl hello.pl';
system($command);
