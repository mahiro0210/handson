print "Hello";
